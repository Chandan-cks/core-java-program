import java.util.ArrayList;

class ArrayListDemo
{
	public static void main(String args[])
	{
		ArrayList al = new ArrayList();
		al.add("java");
		al.add("python");
		al.add("iot");
		al.add("data strature");
		al.add("spring");
		System.out.println(al);
		System.out.println("**Traversing Arraylist through loop**");
		for(int i=0;i<al.size();i++)
		{
			System.out.println(al.get(i));
		}
		System.out.println("**Traversing Arraylist through enhance for loop**");
		
		for(Object s : al)
		{
			String Course = s.toString();
			System.out.println(Course.toUpperCase());
		}
		
	}
}