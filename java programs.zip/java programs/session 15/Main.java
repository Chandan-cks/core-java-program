interface A
{
	void show1();
}
interface B
{
	void show2();
}
class Test implements A,B
{
	public void show1()
	{
		System.out.println("show1()...");
	}
	public void show2()
	{
		System.out.println("show2()...");
	}
}
class Main
{
	public static void main(String args[])
	{
	Test ob = new Test();
	ob.show1();
	ob.show2();
	}
}