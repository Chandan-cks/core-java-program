interface Intf1
{
	default void show()
	{
		System.out.println("defult method of Intf1 ");
	}
}
interface Intf2
{
	default void show()
	{
		System.out.println("defult method of Intf2 ");
	}
}
class Best implements Intf1 ,Intf2
{
	public void show()
	{
		Intf1.super.show();
		Intf2.super.show();	
	}
}
class Demethod1
{
	public static void main(String args[])
	{
		Best ob = new Best();
		ob.show();
	}
}
//multiple interface defult method