interface Intf1
{
	static void show()
	{
		System.out.println("static method of Intf1 ");
	}
}
class StaticMethodDemo
{
	public static void main(String args[])
	{
		Intf1.show();
	}

}