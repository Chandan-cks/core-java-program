interface Test
{
	default void show()
	{
		System.out.println("defult method ....");
	}
}
class Best implements Test
{

}
class Demethod
{
	public static void main(String args[])
	{
	Best ob = new Best();
	ob.show();
	}
}