import java.io.FileInputStream;
import java.io.FileOutputStream;


class Mergemp3
{
	public static void main(String args[])throws Exception
	{
		FileInputStream fin1 = new FileInputStream("d:\\a.mp3");
		FileInputStream fin2 = new FileInputStream("d:\\b.mp3");
		FileOutputStream fout = new FileOutputStream("d:\\c.mp3");
		System.out.println("processing...");
		int c = fin1.read();
		while(c!=-1)
		{
			fout.write(c);
			c = fin1.read();
		}
		c = fin2.read();
		while(c!=-1)
		{
			fout.write(c);
			c = fin2.read();
		}
		fout.close();

		System.out.println("mp3file will be merge successfully....");
	}
}