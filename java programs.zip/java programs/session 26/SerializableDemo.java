import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
class Student implements Serializable
{
	String name;
	int age;
}
class SerializableDemo
{
	public static void main(String args[])throws Exception
	{
		Student s = new Student();
		s.name = "chandan";
		s.age = 10;
		FileOutputStream fout = new FileOutputStream("d:\\data.txt");
		
		ObjectOutputStream oos = new ObjectOutputStream(fout);
		oos.writeObject(s);
		oos.close();
		fout.close();
		System.out.println("object saved successfully");
	}
}