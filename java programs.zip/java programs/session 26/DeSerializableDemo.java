import java.io.FileInputStream;
import java.io.ObjectInputStream;

class DeSerializableDemo
{
	public static void main(String args[])throws Exception
	{
		
		FileInputStream fin = new FileInputStream("d:\\data.txt");
		
		ObjectInputStream ois = new ObjectInputStream(fin);
		Student s = (Student)ois.readObject();

		System.out.println("Nmae = "+s.name);
		System.out.println("age = "+s.age);
	}
}