/*how to create a folder programitically*/



import java.io.File;
class CreateFolder
{
	public static void main(String args[])
	{
		File f1 = new File("d:\\java");
		f1.mkdir();
		File f2 = new File("d:\\java\\demo");
		f2.mkdirs();
	}
}