import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.File;

class MoveFile
{
	public static void main(String args[])throws Exception
	{
		File f = new File("d:\\data.txt");
		FileInputStream fin = new FileInputStream(f);
		FileOutputStream fout = new FileOutputStream("f:\\move.txt");
		
		int c = fin.read();
		while(c!=-1)
		{
			fout.write(c);
			c = fin.read();
		}
		fout.close();
		fin.close();
		f.delete();
		System.out.println("file moved sucessfully and delete from source file");
	}
}	