class Test
{
	void show1()
	{
		System.out.println("start game");
	}
}
interface Intf
{
	void show2();
}
class Best extends Test implements Intf
{
	public void show2()
	{
		System.out.println("it's show time...");
	}
}
class Maincase1
{
	 public static void main(String args[])
	{
		Best ob = new Best();
		ob.show1();
		ob.show2();

	}
} 