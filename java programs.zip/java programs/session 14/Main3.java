abstract class Test
{
	abstract void show1();
	abstract void show2();
	abstract void show3();
}
abstract class Best extends Test
{
	void show1()
	{
	System.out.println("Sahoo1");

	}
}
class Nest extends Best
{
	void show2()
	{
	System.out.println("Sahoo2");

	}

	void show3()
	{
	System.out.println("Sahoo3");

	}

}
class Main3
{
	public static void main(String args[])
	{
		Nest ob =  new Nest();
		ob.show1();
		ob.show2();
		ob.show3();
	}
}
