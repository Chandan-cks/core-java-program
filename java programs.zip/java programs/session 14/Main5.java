interface Test
{
	void show();
}
class Best implements Test
{
	public void show()
	{
		System.out.println("it's show time...");
	}
}
class Main5
{
	 public static void main(String args[])
	{
		Best ob = new Best();
		ob.show();
	}
}