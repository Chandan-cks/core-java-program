abstract class Test
{
	abstract void show();
}
class Best extends Test
{
	void show()
	{
	System.out.println("Sahoo");

	}
}
class Main2
{
	public static void main(String args[])
	{
		Best ob =  new Best();
		ob.show();
	}
}