interface Test
{
	void show();
}
class Best implements Test
{
	public void show()
	{
		System.out.println("it's show time...");
	}
}
class Main6
{
	 public static void main(String args[])
	{
		Test ob = new Best();
		ob.show();
		System.out.println(ob.getClass().getName());
	}
}