abstract class Test
{
	void show()
	{
		System.out.println("it's show time");
	}
}
class Best extends Test
{
	
}
class Main
{
	public static void main(String args[])
	{
		Best ob =  new Best();
		ob.show();
	}
}