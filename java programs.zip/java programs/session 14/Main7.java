class Test
{
	interface Intf
	{
		void show();
	}
}
class Best implements Test.Intf
{
	public void show()
	{
		System.out.println("it's show time...");
	}
}
class Main7
{
	 public static void main(String args[])
	{
		Best ob = new Best();
		ob.show();
		
	}
}