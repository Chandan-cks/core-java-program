import pack.Test;
class Main
{
	public static void main(String args[])
	{
		Test ob = new Test();
		ob.show();
	}
}