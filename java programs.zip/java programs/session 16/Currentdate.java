import java.util.Date;

class Currentdate
{
	public static void main(String args[])
	{
		Date dt = new Date();
		System.out.println(dt);
	}
}