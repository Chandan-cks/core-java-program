import java.util.Random;
class Otp
{
	public static void main(String args[])
	{
		Random ob = new Random();
		String otp ="";
		for(int i=1;i<6;i++)
		{
			otp = otp + ob.nextInt(10);
		}
		
		System.out.println(otp);
	}
}