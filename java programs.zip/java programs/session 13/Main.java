class Test
{
	void show()
	{
	System.out.println("inside test show()....");
	}
}
class Best extends Test
{
	void show()
	{
		System.out.println("inside best show()...");

	}
}
class Main
{
	public static void main(String args[])
	{
		Test ob = new Best();
		ob.show();
	}
}