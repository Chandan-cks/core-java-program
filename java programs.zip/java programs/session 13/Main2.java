
class Main2
{
	public static void main(String args[])
	{
		fiinal int a = 10;
		a++;
		Syatem.out.println(a);
	}
}