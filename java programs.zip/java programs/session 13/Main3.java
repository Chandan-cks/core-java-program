class Test
{
	int a = 1;
	int b = 2;
}
class Best extends Test
{
	
	int a = 10;
	int b = 20;
	void show(int a , int b)
	{
		System.out.println(a+b);
		System.out.println(this.a+this.b);
		System.out.println(super.a+super.b);
	}
}
class Main3
{
	public static void main(String args[])
	{
		Best ob = new Best();
		ob.show(100,200);
	}
}