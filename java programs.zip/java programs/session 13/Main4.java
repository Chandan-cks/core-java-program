class Test
{

}

class Best extends Test
{
	
	Best()
	{
		System.out.println("child class constructor...");
	
	}
}
class Main4
{
	public static void main(String args[])
	{
		Best ob = new Best();
	}
}