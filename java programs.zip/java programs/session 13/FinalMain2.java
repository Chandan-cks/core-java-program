final class Test
{
	final void show()
	{
	System.out.println("inside test show()....");
	}
}
class Best extends Test
{
	void show()
	{
		System.out.println("inside best show()...");

	}
}
class FinalMain2
{
	public static void main(String args[])
	{
		Test ob = new Best();
		ob.show();
	}
}