class Test
{
	Test()	
	{
		System.out.println("test constructor");
	}
}
class Best
{
	Best()	
	{
		System.out.println("Best constructor");
	}
}
class Demo2
{
	public static void main(String args[])throws Exception
	{
		Class c1 = Class.forName(args[0]);
		c1.newInstance();
		Class c2 = Class.forName(args[1]);
		c2.newInstance();
	}
}