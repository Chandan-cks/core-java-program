class Test
{
	static
	{
		System.out.println("static block");
	}
	Test()
	{
		System.out.println("constructor");
	}
}
class Staticblock
{
	public static void main(String args[])
	{
		Test t = new Test();
	}
}