class Test
{
	Test()
	{
		System.out.println("welcome");
		System.out.println("welcome");
		System.out.println("welcome");
	}

	Test(int x)
	{
		System.out.println("welcome");
		System.out.println("welcome");
		System.out.println("welcome");
	}

	Test(int x ,int y)
	{
		System.out.println("welcome");
		System.out.println("welcome");
		System.out.println("welcome");
	}
	{
		System.out.println("instance block");
	}
}
class Inblock
{
	public static void main(String args[])
	{
		Test t1 = new Test();
		Test t2 = new Test(10);
		Test t3 = new Test(10,20);
	}
}