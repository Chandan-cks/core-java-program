class Test
{
	Test()
	{
		System.out.println("constructor");
	}

	{
		System.out.println("instance block");
	}
}
class Inblock2
{
	public static void main(String args[])
	{
		Test t = new Test();
	}
}