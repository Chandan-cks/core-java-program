import java.util.*;

class HashmapDemo
{
	public static void main(String args[])
	{
		HashMap hm = new HashMap();
		hm.put("java","1 month");
		hm.put("python","2 month");
		hm.put("iot","1 month");
		hm.put("data structure","2 month");
		
		System.out.println(hm);

		System.out.println(hm.get("python"));
	}
}