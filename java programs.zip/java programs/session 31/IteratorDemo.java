import java.util.*;

class IteratorDemo
{
	public static void main(String args[])
	{
		ArrayList al = new ArrayList();
		for(int i=1;i<=10;i++)
		{
			al.add(i);
		}
		System.out.println(al);
		Iterator i = al.iterator();
		while(i.hasNext())
		{
			Integer data = (Integer)i.next();
			if(data %2 ==0)//if(data %2 !=0)//
			{
				i.remove();
			}
		}
		System.out.println(al);
	}
}