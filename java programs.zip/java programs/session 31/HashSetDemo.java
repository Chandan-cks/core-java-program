import java.util.HashSet;

class HashSetDemo
{
	public static void main(String args[])
	{
		HashSet hs = new HashSet();
		hs.add("java");
		hs.add("python");
		hs.add("machine learning");
		hs.add("iot");
		for(Object o : hs)
		{
			String course = o.toString();
			System.out.println(course);
		}
	}
}