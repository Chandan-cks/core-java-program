import java.util.*;

class ListIteratorDemo
{
	public static void main(String args[])
	{
		ArrayList al = new ArrayList();
		for(int i=1;i<=10;i++)
		{
			al.add(i);
		}
		System.out.println("forward derection : ");
		ListIterator li = al.listIterator();
		while(li.hasNext())
		{
			Integer data = (Integer)li.next();
			System.out.println(data);
			
		}
		System.out.println("backword derection : ");
		while(li.hasPrevious())
		{
			Integer data = (Integer)li.previous();
			System.out.println(data);
			
		}
	}
}