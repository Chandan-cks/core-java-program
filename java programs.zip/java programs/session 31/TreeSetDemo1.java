import java.util.TreeSet;

class TreeSetDemo1
{
	public static void main(String args[])
	{
		TreeSet ts = new TreeSet();
		ts.add("A");
		ts.add("B");
		ts.add("C");
		ts.add("D");
		System.out.println(ts);
	}
}