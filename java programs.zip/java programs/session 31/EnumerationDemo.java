import java.util.*;

class EnumerationDemo
{
	public static void main(String args[])
	{
		Vector v = new Vector();
		for(int i=1;i<=10;i++)
		{
			v.add(i);
		}
		Enumeration e = v.elements();
		while(e.hasMoreElements())
		{
			String s = e.nextElement().toString();
			System.out.println(s);
		}
	}
}