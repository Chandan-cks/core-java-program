import java.util.Scanner;

class ScannerDemo2
{
	public static void main(String args[])
	{
		Scanner ob = new Scanner(System.in);
		
		System.out.print("enter num1: ");
		int n1 = ob.nextInt();
		
		System.out.print("enter num2: ");
		int n2 = ob.nextInt();		
		
		int res = n1 + n2;
		System.out.println("Sum = "+res);
	}
}