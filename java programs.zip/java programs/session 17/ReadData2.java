import java.io.BufferedReader;
import java.io.InputStreamReader;

class ReadData2
{
	public static void main(String args[])throws Exception
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("enter num1 : ");
			int n1 = Integer.parseInt(br.readLine());
			System.out.println("enter num2 : ");
			int n2 = Integer.parseInt(br.readLine());
			int res = n1+n2;
			System.out.println("sum = "+res);
	}
}
