class Main2
{
	public static void main(String args[])
	{
		String str1 = new String("java");
		String str2 = new String("python");
		String str3 = new String("java");
	System.out.println(str1.equals(str2));
	System.out.println(str1.equals(str3));
	}
}//
