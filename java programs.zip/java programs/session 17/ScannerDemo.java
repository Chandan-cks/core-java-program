import java.util.Scanner;

class ScannerDemo
{
	public static void main(String args[])
	{
		Scanner ob = new Scanner(System.in);
		System.out.print("Enter your address :");
		String address = ob.nextLine();
		System.out.print("Enter your name :");
		String name = ob.next();

		System.out.print("Enter your emailid :");
		String emailid = ob.next();

		System.out.print("Enter your mobile no :");
		String mobileno = ob.next();


		System.out.println("Name ="+name);
		System.out.println("email id ="+emailid);
		System.out.println("mobile no ="+mobileno);
		System.out.println("Adress ="+address);
	}
}