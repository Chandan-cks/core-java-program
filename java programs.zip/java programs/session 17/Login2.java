import java.io.BufferedReader;
import java.io.InputStreamReader;


class Login2
{
	public static void main(String args[])throws Exception
	{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("enter your login id : ");
			String loginid = br.readLine();
			System.out.println("enter your password : ");
			
			String password= br.readline();
			
		if(loginid.equals("admin")&&password.equals("1234"))
		{
			System.out.println("Valid user...");
		}
		else
		{
			System.out.println("you should type correct code");
		}

	}
}