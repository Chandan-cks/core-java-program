class Test
{
	void add(int x,int y)
	{

		System.out.println("sum = "+(x+y));
		System.out.println("sub = "+(x-y));
		System.out.println("mul = "+(x*y));
	}
}
class MethordDemo
{
	public static void main(String args[])
	{
		Test t = new Test();
		t.add(1,2);
		t.add(10,20);
		t.add(100,200);
	}
}