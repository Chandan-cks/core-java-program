class Test
{
	int  add(int x,int y)
	{

		return x+y;
	}
}
class MethordDemo1
{
	public static void main(String args[])
	{
		Test t = new Test();
		int sum  = t.add(10,20);
		System.out.println("sum = "+sum);
	}
}