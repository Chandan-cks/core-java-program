class Test1{  
	static public void main(String args[])
	{  
     System.out.println("Hello Java");  
        }  
} 