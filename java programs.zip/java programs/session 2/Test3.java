class Test3
{
	public static void main(String []args)
	{
		System.out.println("welcome to java");
	}
}