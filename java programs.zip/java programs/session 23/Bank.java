class Account
{
	float balance = 20000;
	void passChq(String ThreadName, float amount)
	{
		if(amount < balance)
		{
			System.out.println("processig "+ThreadName);
			
			try
			{
				Thread.sleep(2000);
			}
			catch(Exception e)
			{
				System.out.println("Error : "+e);
			}
			balance = balance - amount;
			System.out.println(ThreadName  +" is passed");
		}
		else
		{
			System.out.println(ThreadName +" is not passed");
		}
	}
}
class Process extends Thread
{
	String ThreadName;
	float amount;
	Account obj;

	Process(Account obj, String ThreadName, float amount)
	{
		this.obj = obj;
		this.ThreadName = ThreadName;
		this.amount = amount;
	}
	public void run()
	{
		obj.passChq(ThreadName, amount);
	}
}
class Bank
{
	public static void main(String args[])
	{
		Account obj = new Account();
		Process chq1 = new Process(obj, "cheque1", 15000);
		Process chq2 = new Process(obj, "cheque2", 10000);
		chq1.start();
		chq2.start();
	}
}