class MyThread implements Runnable
{
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println("child thread : "+i);
		}
	}
}
class Multithreading2
{
	public static void main(String args[])
	{
		MyThread mt = new MyThread();
		Thread t = new Thread(mt);
		t.start();

		for(int i=1;i<=10;i++)
		{
			System.out.println("Main : "+i);		
		}
	}
}
//multithreading exectution through a object//