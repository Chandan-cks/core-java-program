class Test
{
	void show()
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println("Test : "+i);		
		}
	}
}
class Sequential
{
	public static void main(String args[])
	{
		Test ob = new Test();
		ob.show();
		for(int i=1;i<=10;i++)
		{
			System.out.println("Main : "+i);		
		}
	}
}
//sequential excetution