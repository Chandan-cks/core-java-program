clas MyThread extends Thread
{
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println("child thread : "+i);
		}
	}Mu
}
class Multithreading
{
	public static void main(String args[])
	{
		MyThread mt = new MyThread();
		mt.start();

		for(int i=1;i<=10;i++)
		{
			System.out.println("Main : "+i);		
		}
	}
}
//multithreading exectution