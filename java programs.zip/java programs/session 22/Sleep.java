class MyThread extends Thread
{
	public void run()
	{
		for(int i=1;i<=5;i++)
		{
			System.out.println("Child Thread : "+i);
			try
			{
				Thread.sleep(2000);
			}
			catch(Exception e)
			{
				
			}
		}
		System.out.println("End of child thread");
	}
}
class Sleep
{
	public static void main(String args[])throws Exception
	{
		MyThread mt = new MyThread();
		mt.start();
		
		for(int i=1;i<=5;i++)
		{
			System.out.println("Main Thread : "+i);
			Thread.sleep(1000);
		}
		mt.join();
		System.out.println("end of main thread");
	}
}