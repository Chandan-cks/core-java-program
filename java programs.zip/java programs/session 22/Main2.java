class Main2
{
	public static void main(String args[])
	{
		Thread ob = new Thread();
		ob.setName("main Thread");
		System.out.println("thread Name = "+ob.getName());
	}
}