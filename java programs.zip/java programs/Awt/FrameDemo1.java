import java.awt.*;
class FrameDemo1
{
	public static void main(String args[])
	{
		Frame ob = new Frame();
		ob.setVisible(true);
		ob.setSize(500,200);
		ob.setBackground(Color.red);
	}
}