import java.awt.*;
import java.awt.event.*;

class Calculator
{
	public static void main(String args[])
	{
		Frame f = new Frame("Text Field");
		f.setBackground(Color.blue);
		Label l1,l2,lresult;
		TextField tf1,tf2;
		Button btnAdd,btnSub,btnMul,btnDiv;

		l1=new Label("Enter num 1 : ");
		l1.setBounds(40,60,200,30);
		l1.setForeground(Color.white);
		tf1 = new TextField();
		tf1.setBounds(40,100,220,30);

		l2=new Label("Enter num 2 : ");
		l2.setBounds(40,140,220,30);
		tf2 = new TextField();
		tf2.setBounds(40,180,220,30);

		btnAdd = new Button("Add");
		btnAdd.setBounds(40,220,50,30);
		btnSub = new Button("Sub");
		btnSub.setBounds(100,220,50,30);
		btnMul = new Button("Mul");
		btnMul.setBounds(160,220,50,30);
		btnDiv = new Button("Div");
		btnDiv.setBounds(220,220,50,30);

		lresult = new Label("Result : ");
		lresult.setBounds(40,260,200,30);

		f.add(l1);
		f.add(tf1);
		f.add(l2);
		f.add(tf2);
		f.add(btnAdd);
		f.add(btnSub);
		f.add(btnMul);
		f.add(btnDiv);
		
		f.add(lresult);
		
		f.setSize(400,400);
		f.setLayout(null);
		f.setVisible(true);

		btnAdd.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				int n1 = Integer.parseInt(tf1.getText());
				int n2 = Integer.parseInt(tf2.getText());
				int res = n1+n2;
				lresult.setText("Result = "+res);
			}
		});
		btnSub.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				int n1 = Integer.parseInt(tf1.getText());
				int n2 = Integer.parseInt(tf2.getText());
				int res = n1-n2;
				lresult.setText("Result = "+res);
			}
		});
		btnMul.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				int n1 = Integer.parseInt(tf1.getText());
				int n2 = Integer.parseInt(tf2.getText());
				int res = n1*n2;
				lresult.setText("Result = "+res);
			}
		});
		btnDiv.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				int n1 = Integer.parseInt(tf1.getText());
				int n2 = Integer.parseInt(tf2.getText());
				int res = n1/n2;
				lresult.setText("Result = "+res);
			}
		});
		f.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent arg)
			{
				System.exit(0);
			}
		});
	}
}