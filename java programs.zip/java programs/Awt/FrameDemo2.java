import java.awt.*;
class MyFrame extends Frame
{
	MyFrame()
	{
		setVisible(true);
		setSize(500,200);
		setTitle("Demo Frame");
		setBackground(Color.red);
	}
}
class FrameDemo2
{
	public static void main(String args[])
	{
		MyFrame ob = new MyFrame();
		
	}
}