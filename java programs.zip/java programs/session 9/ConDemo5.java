class Test
{
	Test()
	{
		this(1);
		System.out.println("0-arg constructor...");
	}

	Test(int x)
	{
		System.out.println("parameterized constructor...");
	}
}
class ConDemo5
{
	public static void main(String args[])
	{
		Test t = new Test();

	}
}
