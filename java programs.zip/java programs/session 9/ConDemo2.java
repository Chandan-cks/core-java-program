class Student
{
	String name;
	int age;
	Student()
	{
		name ="ram";
		age = 10;	
	}
}
class ConDemo2
{
	public static void main(String args[])
	{
		Student s1 = new  Student();
		Student s2 = new  Student();
		Student s3 = new  Student();

		System.out.println("name = "+s1.name+" age = "+s1.age);
		System.out.println("name = "+s2.name+" age = "+s2.age);
		System.out.println("name = "+s3.name+" age = "+s3.age);
	}
}
//Zero arg constructor