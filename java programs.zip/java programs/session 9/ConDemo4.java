class Student
{
	String name;
	int age;
	Student(String name,int age)
	{
		name =name;
		age = age;	
	}
}
class ConDemo4
{
	public static void main(String args[])
	{
		Student s1 = new  Student("ram",10);
		System.out.println("name = "+s1.name+" age = "+s1.age);

	}
}
