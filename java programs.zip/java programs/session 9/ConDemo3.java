class Student
{
	String name;
	int age;
	Student(String n,int a)
	{
		name =n;
		age = a;	
	}
}
class ConDemo3
{
	public static void main(String args[])
	{
		Student s1 = new  Student("ram",10);
		Student s2 = new  Student("raka",20);
		Student s3 = new  Student("rabi",30);

		System.out.println("name = "+s1.name+" age = "+s1.age);
		System.out.println("name = "+s2.name+" age = "+s2.age);
		System.out.println("name = "+s3.name+" age = "+s3.age);
	}
}
//Zero arg constructor