class Rectangle
{
	int length;
	int breath;
	Rectangle()
	{
		length = 0;
		breath = 0;
	}
 
	Rectangle(int x)
	{
		length = x;
		breath = x;
	}

	Rectangle(int x,int y)
	{
		length = x;
		breath = y;
	}
	void area()
	{
		System.out.println("Area = "+(length*breath));
	}
}
class Area
{
	public static void main(String args[])
	{

		Rectangle r1 = new Rectangle();
		Rectangle r2 = new Rectangle(10);
		Rectangle r3 = new Rectangle(10,20);
		r1.area();
		r2.area();
		r3.area();
	}
}