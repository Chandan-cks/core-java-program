class Student
{
	Student()
	{
		System.out.println("welcome guest");
	}
 
	Student(String name)
	{
		System.out.println("welcome "+name);
	}
}
class Que1
{
	public static void main(String args[])
	{
		Student s1 = new Student();
		Student s2 = new Student("ram");
	}
}