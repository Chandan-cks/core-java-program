class Test
{
	
}
class RefDemo
{
	public static void main(String args[])
	{
		Test t1 = new Test();
		Test t2 = new Test();
		Test t3 = new Test();
		Test a1 = t1;
		Test a2 = t2;
		Test a3 = t3;
	System.out.println("t1 hash code = "+t1.hashCode());
	System.out.println("t2 hash code = "+t2.hashCode());	
	System.out.println("t3 hash code = "+t3.hashCode());
	System.out.println("a1 hash code = "+a1.hashCode());	
	System.out.println("a2 hash code = "+a2.hashCode());
	System.out.println("a3 hash code = "+a3.hashCode());
	}
}