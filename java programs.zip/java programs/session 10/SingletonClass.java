class Test
{
	static Test ob = new Test();
	private Test()
	{
		System.out.println("constructor");

	}
	static Test create()
	{
		return ob;
	}
}
class SingletonClass
{
	public static void main(String args[])
	{
		Test t1 = Test.create();
		Test t2 = Test.create();
		System.out.println(t1.hashCode());
		System.out.println(t2.hashCode());
	}	
}
