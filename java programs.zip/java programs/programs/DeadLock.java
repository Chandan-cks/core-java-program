class Test
{
	public synchronized void show1(Best b)
	{	
		System.out.println("Thread1 starts execution of show1()");
		try
		{
			Thread.sleep(6000);
		}
		catch(Exception e)
		{	
		}
		System.out.println("Thread1 is trying to call last() of Best");
		b.last();	
	}
	public synchronized void last()
	{	
		System.out.println("last() method of Test");
	}
}
class Best
{
	public synchronized void show2(Test t)
	{	
		System.out.println("Thread2 starts execution of show2()");
		try
		{
			Thread.sleep(6000);
		}
		catch(Exception e)
		{	
		}
		System.out.println("Thread2 is trying to call last() of Test");
		t.last();	
	}
	public synchronized void last()
	{	
		System.out.println("last() method Best");
	}
}
class DeadLock extends Thread
{
	Test t = new Test();
	Best b = new Best();
	public void m1()
	{	
		this.start();
		t.show1(b);	
	}
	public void run()
	{	
		b.show2(t);	
	}
	public static void main(String args[])
	{	
		DeadLock1 d = new DeadLock1();
		d.m1();	
	}
}
