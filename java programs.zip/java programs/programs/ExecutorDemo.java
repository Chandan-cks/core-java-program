import java.util.concurrent.*;

class PrintJob implements Runnable
{
	String name;
	PrintJob(String name)
	{	
		this.name = name;	
	}
	public void run()
	{
		System.out.println(name + " job started by thread : "+Thread.currentThread().getName());
		try
		{	
			Thread.sleep(5000);	
		}	
		catch(Exception e){}
		System.out.println(name + "job completed by thread : "+Thread.currentThread().getName());
		
	}
}
class ExecutorDemo
{
	public static void main(String args[])
	{
		PrintJob jobs[] = { new PrintJob("A"),new PrintJob("B"),new PrintJob("C"),new PrintJob("D"),new PrintJob("E")};
		ExecutorService service = Executors.newFixedThreadPool(2);
		for(PrintJob job: jobs)
		{	
			service.submit(job);	
		}
		service.shutdown();	
	}
}
