class Test3
{
	int i;
	Test3 tt;
	void start()
	{
		tt = new Test3();
		this.takeDemo(tt);
		i++;
	}
	void takeDemo(Test3 t)
	{
	t=null;
	t=new Test3();
	i=10;	
	}
	public static void main(String args[])
	{
		Test3 a =new Test3();
		a.start();
		System.out.println("value of i = "+a.i);
	}
}