class Test
{
	public static void main(String args[])
	{
		class foo
		{
			int i = 3;
		}
	Object o = new foo();
	foo foo = (foo)o;
	System.out.println("i = "+foo.i);
	}
}