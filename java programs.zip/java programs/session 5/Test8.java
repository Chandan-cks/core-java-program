class Test8
{
	public static void main(String args[])
	{
		
		System.out.println(3 & 7);

		System.out.println(5 | 13);

		System.out.println(9 ^ 2);
	}
}
//& = aleast one is zero output is zero.
//| = aleast one is one output is one.
//^ = aleast one is one output is one