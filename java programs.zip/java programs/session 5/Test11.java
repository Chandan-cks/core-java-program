class Test11
{
	public static void main(String args[])
	{
		int a = 10<<2;
		System.out.println(a);
	}
}
//used << this operater we used '*'.
//>> this operater we used '/'.