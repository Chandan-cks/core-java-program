class Test10
{
	public static void main(String args[])
	{
		int a = Integer.parseInt(args[0]);
		int b = Integer.parseInt(args[1]);
		String result = a>b? a+" is greater" : b+ " is greater";
		System.out.println(result);
	}
}