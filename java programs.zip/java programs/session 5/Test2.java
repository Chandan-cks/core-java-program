class Test2
{
	public static void main(String args[])
	{
		char ch = '8';
		ch++;
		System.out.println(ch); 
	}
}