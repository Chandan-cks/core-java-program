class Test6
{
	public static void main(String args[])
	{
		byte b = 10;
		b+1;
		System.out.println(b); 
	}
}
/*byte b =10;
b = b+1;
max(int ,byte ,int)*/0