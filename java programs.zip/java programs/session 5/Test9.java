class Test9
{
	public static void main(String args[])
	{
		int x,y,z = 10;
		x =y = z = 10;
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);
	}
}
//result = condition ? exp1: exp2;