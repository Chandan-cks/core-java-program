class Test1
{
	public static void main(String args[])
	{
		char ch = 'a';
		ch++;
		System.out.println(ch); 
	}
}