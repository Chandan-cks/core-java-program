class Student
{
	String name = "ram";
	int age = 10;
}
class Demo
{
	public static void main(String args[])
	{
		Student s = new Student();
		System.out.println("name = "+s.name);
		System.out.println("age = "+s.age);
	}
}