class Test
{
	int x = 10;
	static int y = 20; 
}
class Demo1
{
	public static void main(String args[])
	{
		Test t = new Test();


		System.out.println(t.x);
		System.out.println(t.y);
		System.out.println(Test.y);
	}
}