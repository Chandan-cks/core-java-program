import java.io.FileInputStream;

class ReadData1
{
	public static void main(String args[])throws Exception
	{
		FileInputStream fin = new FileInputStream("d:\\data.txt");
		int c = fin.read();
		while(c!=-1)
		{
			System.out.print((char)c);
			c = fin.read();
		}
	fin.close();
	}
}