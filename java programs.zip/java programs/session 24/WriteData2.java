import java.io.FileWriter;

class WriteData2
{
	public static void main(String args[])throws Exception
	{
		String data = "gyan bro";
		FileWriter fw = new FileWriter("d:\\data.txt");
	fw.write(data);
	fw.close();
	System.out.println("data saved sucessfully...");
	}
}