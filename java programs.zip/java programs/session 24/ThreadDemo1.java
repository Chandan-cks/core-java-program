class MyThread extends Thread
{
	public  void run()
	{
		Thread t= Thread.currentThread();
		System.out.println("child Thread : "+t.getName());
		t.setPriority(6);
		System.out.println("child Thread Priority : "+t.getPriority());

	}
}
class ThreadDemo1
{
	public static void main(String args[])
	{
		Thread t= Thread.currentThread();
		System.out.println("Main Thread : "+t.getName());
		t.setPriority(10);
		System.out.println("Main Thread Priority : "+t.getPriority());
		
		MyThread mt = new MyThread();
		mt.start();

	}
}