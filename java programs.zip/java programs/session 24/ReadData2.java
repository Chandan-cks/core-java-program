import java.io.FileReader;

class ReadData2
{
	public static void main(String args[])throws Exception
	{
		FileReader fr = new FileReader("d:\\data.txt");
		int c = fr.read();
		while(c!=-1)
		{
			System.out.print((char)c);
			c = fr.read();
		}
	fr.close();
	}
}







