import java.io.FileOutputStream;

class WriteData1
{
	public static void main(String args[])throws Exception
	{
		String data = "chandu";
		FileOutputStream fout = new FileOutputStream("d:\\data.txt");
	fout.write(data.getBytes());
	fout.close();
	System.out.println("data saved sucessfully...");
	}
}