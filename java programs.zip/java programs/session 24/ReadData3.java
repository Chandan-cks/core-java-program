import java.io.FileReader;
import java.io.BufferedReader;

class ReadData3
{
	public static void main(String args[])throws Exception
	{
		FileReader fr = new FileReader("d:\\data.txt");
		BufferedReader br = new BufferedReader(fr);
		
		String data = br.readLine();
		while(data !=null)
		{
			System.out.println(data);
			data = br.readLine();
		}
	br.close();
	fr.close();
	}
}







