class Trycatch4
{
	public static void main(String args[])
	{

		try
		{
			int a = Integer.parseInt(args[0]);
			int b = Integer.parseInt(args[1]);
			int c = a/b;
			System.out.println("result = "+c);
			//System.exit(0); for jvm shutdown
		}
		catch(ArithmeticException e)
		{
			System.out.println("catch block");
		}
		finally
		{
			System.out.println("finally block");
		}
		
		System.out.println("code...");
		System.out.println("code...");
		System.out.println("code...");
	}
}