class Trycatch3
{
	public static void main(String args[])
	{

		try
		{
			int a = Integer.parseInt(args[0]);
			int b = Integer.parseInt(args[1]);
			int c = a/b;
			System.out.println("result = "+c);
		}
		catch(ArithmeticException e)
		{
			System.out.println("Error1 : "+e);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Error2 : "+e);
		}
		catch(Exception e)
		{
			System.out.println("Error3 : "+e);
		}
		
		System.out.println("code...");
		System.out.println("code...");
		System.out.println("code...");
	}
}