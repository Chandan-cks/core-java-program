class Main3
{
	public static void main(String args[])
	{
		int arr[] = {10,20,30,40,50};
		System.out.println(arr.length);
		String str = "bbsr";
		System.out.println(str.length());
	}
}