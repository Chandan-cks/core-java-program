class Heap2
{
	public static void main(String args[])
	{
		String str = new String("bbsr");
		str = str.concat(" slakhya");
		System.out.println(str);
	}
}