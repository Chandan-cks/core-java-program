class Heap3
{
	public static void main(String args[])
	{
		StringBuffer str = new StringBuffer("bbsr");
		
		str.append(" lakhya ");
		
		System.out.println(str);
	}
}