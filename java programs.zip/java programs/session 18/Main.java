class Main
{
	public static void main(String args[])
	{
		String str1 = "java";
		String str2 = "python";
		String str3 = "java";
		System.out.println(str1 == str2);
		System.out.println(str1 == str3);
	}
}