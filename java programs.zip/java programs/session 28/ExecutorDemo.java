import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

class MyThread implements Runnable
{
	String name;
	MyThread(String name)
	{
		this.name = name;
	}
	public void run()
	{
		System.out.println(name + "job started by thread :"+Thread.currentThread().getName());
		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e){}
		System.out.println(name + "job completed by thread"+Thread.currentThread().getName());
	}
}
class ExecutorDemo
{
	public static void main(String args[])
	{
		MyThread jobs[] = {new MyThread("A"),new MyThread("B"),new MyThread("C"),new MyThread("D"),new MyThread("E"),new MyThread("F")};
	
	ExecutorService services = Executors.newFixedThreadPool(4);
	for(MyThread job: jobs)
	{
		services.submit(job);
	}
	services.shutdown();
	}
}