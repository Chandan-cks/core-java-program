import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;
class Agecalculator
{
	public static void main(String args[])
	{
		Scanner s = new Scanner(System.in);
		System.out.println("***Enter Birth Date***");
		System.out.println("Enter year :");
		int year = s.nextInt();
		System.out.println("Enter Month :");
		int month = s.nextInt();
		System.out.println("Enter Date :");
		int date = s.nextInt();
		LocalDate birthday = LocalDate.of(year,month,date);
		LocalDate today = LocalDate.now();
		Period p = Period.between(birthday,today);
		System.out.println("you are"+p.getYears()+"Years,"+p.getMonths()+"months,"+p.getDays()+"days old");
	}
}	