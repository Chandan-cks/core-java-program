import java.time.LocalTime;
class Timeinfo
{
	public static void main(String args[])
	{
		LocalTime time = LocalTime.now();
		System.out.println(time);
		int hour = time.getHour();
		int min = time.getMinute();
		int sec = time.getSecond();
		System.out.println(hour+"/"+min+"/"+sec);
	}
}	