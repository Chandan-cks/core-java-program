class vast
{
	static int i = 1;
	static void show()
	{
		i++;
		System.out.println(i);
		show();
	}
	public static void main(String args[])
	{
		show();
	}
}