class MyException extends Exception
{
	MyException(String msg)
	{
		super(msg);
	}
}
class Best
{
	public static void main(String args[])
	{
		try
		{
			int age = Integer.parseInt(args[0]);
			if(age<18)
			{
				MyException ob = new MyException("you are not eligble for voting");
				throw ob;
			}
			System.out.println("you are eligible for voting...");

		}
		catch(MyException e)
		{
			System.out.println("error : "+e);
		}
	}
}
