import java.io.*;
class Test1
{
	public static void main(String args[])throws FileNotFoundException
	{
		FileOutputStream fout = new FileOutputStream("d:\\data.txt");

	}
}