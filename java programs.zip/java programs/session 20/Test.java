class Test
{
	public static void main(String args[])
	{
		try
		{
			int a = Integer.parseInt(args[0]);
			int b = Integer.parseInt(args[1]);
			if(b==0)
			{
				ArithmeticException ob = new ArithmeticException();
			throw ob;
			}
			int c = a/b;
		System.out.println("Result = "+c);
		}
		catch(ArithmeticException e)
		{
			System.out.println("error :"+e);
		}
			System.out.println("code...");
			System.out.println("code...");
			System.out.println("code...");
	}
}
