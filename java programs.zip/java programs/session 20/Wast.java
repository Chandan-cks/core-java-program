class Wast
{
	public static void main(String args[])
	{
		int arr[] = new int[4];
	}
}