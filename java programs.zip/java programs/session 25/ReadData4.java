import java.io.FileInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;

class ReadData4
{
	public static void main(String args[])throws Exception
	{
		FileInputStream fin = new FileInputStream("d:\\data.txt");
		BufferedReader br = new BufferedReader(new InputStreamReader(fin));
		
		String data = br.readLine();
		while(data !=null)
		{
			System.out.println(data);
			data = br.readLine();

		}
		br.close();
		fin.close();
	}
}