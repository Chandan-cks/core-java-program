import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
class Mergemp3
{
	public static void main(String args[])throws Exception
	{
		FileReader fr = new FileReader("d:\\a.mp3");
		FileReader ft = new FileReader("d:\\b.mp3");
		FileWriter fw = new FileWriter("d:\\c.mp3");

		BufferedReader br = new BufferedReader(fr);

		String data = br.readLine();
		while(data !=null)
		{
			fw.write(data+"\r\n");
			data = br.readLine();
		}
		br = new BufferedReader(ft);
		data = br.readLine();
		while(data !=null)
		{
			fw.write(data+"\r\n");
			data = br.readLine();
		}
		br.close();
		fw.close();//compulsury
		fr.close();
		ft.close();
		System.out.println("mp3file will be merge from data to transfer file...");
	}
}