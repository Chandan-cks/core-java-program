import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;

class CopyFile
{
	public static void main(String args[])throws Exception
	{
		FileReader fr = new FileReader("d:\\data.txt");
		FileWriter fw = new FileWriter("d:\\transfer.txt");

		BufferedReader br = new BufferedReader(fr);
		String data = br.readLine();
		while(data !=null)
		{
			fw.write(data);
			data = br.readLine();
		}
		br.close();
		fw.close();
		fr.close();
		System.out.println("file will be copy from data to transfer file...");
	}
}