import java.io.BufferedReader;
import java.io.InputStreamReader;

class LoginId
{
	public static void main(String args[])throws Exception
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Ente your loginid : ");
		String loginid = br.readLine();

		System.out.print("Ente your password : ");
		String password = br.readLine();
		
		if(loginid.equals("admin") && password.equals("1234"))
		{
			System.out.println("valid userr");
		}
		else
		{
			System.out.println("invalid userr");
		}
	}
}