import java.io.Console;

class InvisiblePass
{
	public static void main(String args[])throws Exception
	{
		Console s = System.console();

		System.out.print("Ente your loginid : ");
		String loginid = s.readLine();

		System.out.print("Ente your password : ");
		char arr[] = s.readPassword();
		String password = String.valueOf(arr);
		
		if(loginid.equals("admin") && password.equals("1234"))
		{
			System.out.println("valid userr");
		}
		else
		{
			System.out.println("invalid user");
		}
	}
}