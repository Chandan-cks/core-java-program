import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;

class Merge
{
	public static void main(String args[])throws Exception
	{
		FileReader fr = new FileReader("d:\\data.txt");
		FileReader ft = new FileReader("d:\\Transfer.txt");
		FileWriter fw = new FileWriter("d:\\merge.txt");

		BufferedReader br = new BufferedReader(fr);

		String data = br.readLine();
		while(data !=null)
		{
			fw.write(data+"\r\n");
			data = br.readLine();
		}
		br = new BufferedReader(ft);
		data = br.readLine();
		while(data !=null)
		{
			fw.write(data+"\r\n");
			data = br.readLine();
		}
		br.close();
		fw.close();//compulsury
		fr.close();
		ft.close();
		System.out.println("file will be merge from data to transfer file...");
	}
}