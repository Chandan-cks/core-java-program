class Converttime
{
	public static void main(String args[])
	{
		int milli = Integer.parseInt(args[0]);
		int min = milli/60000;
		int sec = (milli%60000)/1000;
		System.out.println("milli = "+milli);

		System.out.println("minute = "+min);

		System.out.println("second = "+sec);
	}
}