class Test
{
	
	void show()
	{
		System.out.println("inside show()...");
	
	}
}
class Best extends Test
{
	
	void show()
	{
		System.out.println("inside display()...");
	
	}
}
class Mor
{
	public static void main(String args[])
	{
		Best ob = new Best();
		ob.show();
	}
}