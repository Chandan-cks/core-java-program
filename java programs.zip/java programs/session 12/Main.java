class Test
{
	int a = 10;
	void show()
	{
		System.out.println("inside show()...");
	
	}
}
class Best extends Test
{
	int b = 20;
	void Display()
	{
		System.out.println("inside display()...");
	
	}
}
class Main
{
	public static void main(String args[])
	{
		Best ob = new Best();
		System.out.println(ob.a);
		System.out.println(ob.b);
		ob.show();
		ob.Display();
	}
}