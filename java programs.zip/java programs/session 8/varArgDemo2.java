class Test
{
	void add(int ...x)
	{
		int sum = 0;
		for(int i=0;i<x.length;i++)
		{
			sum = sum + x[i];
		}
		System.out.println("sum = "+sum); 
	}

}
class varArgDemo2
	{
		public static void main(String args[])
		{
			Test t = new Test();
			t.add();
			t.add(10);
			t.add(10,20);
			t.add(10,20,30);
			t.add(1,2,3,4,5);
		}
	}
//vararg method is no of argument can pass at a time.