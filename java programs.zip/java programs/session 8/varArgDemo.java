class Test
{
	void add(int ...x)
	{

	}

}
class varArgDemo
	{
		public static void main(String args[])
		{
			Test t = new Test();
			t.add();
			t.add(10);
			t.add(10);	
		}
	}