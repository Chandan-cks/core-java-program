class Test
{
	void add(int x, int y)
	{
		System.out.println(x+y);
	}

	void add(float x, float y)
	{
		System.out.println(x+y);
	}
}
class Mol2
	{
		public static void main(String args[])
		{
			Test t = new Test();
			t.add(10,20);
			t.add(10.2f,20.2f);
		}
	}