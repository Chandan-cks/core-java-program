class Test
{
	void add(int x, float y)
	{
		System.out.println(x+y);
	}

	void add( float x, int y)
	{
		System.out.println(x+y);
	}
}
class Mol3
	{
		public static void main(String args[])
		{
			Test t = new Test();
			t.add(10,20.2f);
			t.add(10.2f,20);
		}
	}