class Test
{
	void add(int x, int y)
	{
		System.out.println(x+y);
	}

	void add(int x, int y,int z)
	{
		System.out.println(x+y+z);
	}
}
class Mol
	{
		public static void main(String args[])
		{
			Test t = new Test();
			t.add(10,20);
			t.add(10,20,30);
		}
	}