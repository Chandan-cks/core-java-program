import java.util.Scanner;
class ArrayDemo2
{
	public static void main(String args[])
	{
		Scanner s = new Scanner(System.in);
		int arr[] = new int[10];
		System.out.println("Enter array size : ");
		int size = s.nextInt();
		for(int i=0;i<size;i++)
		{
			arr[i] = s.nextInt();
		}
		System.out.print("Enter position: ");
		
		int pos = s.nextInt();
		
		System.out.println("Enter element: ");
		int ele = s.nextInt();
		
		for(int i=size;i>pos;i--)
		{
			arr[i] = arr[i-1];
		}
		arr[pos] = ele;
		size++;
		System.out.println("Display array : ");
		for(int i=0;i<size;i++)
		{
			System.out.println(arr[i]);
		}
	}
}