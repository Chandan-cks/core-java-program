import java.util.Scanner;
class ArrayDemo
{
	public static void main(String args[])
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter array size : ");
		int size = s.nextInt();
		int arr[] = new int[size];
		System.out.println("Read array : ");
		
		for(int i=0;i<size;i++)
		{
			arr[i] = s.nextInt();
		}
		System.out.println("Display array : ");
		for(int i=0;i<size;i++)
		{
			System.out.println(arr[i]);
		}
	}
}