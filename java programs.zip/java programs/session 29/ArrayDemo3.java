import java.util.Scanner;
class ArrayDemo3
{
	public static void main(String args[])
	{
		Scanner s = new Scanner(System.in);
		int arr[][] = new int[3][];
		arr[0] = new int[1];
		arr[1] = new int[2];
		arr[2] = new int[3];
		System.out.println("Read array : ");
		for(int i=0;i<=2;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				arr[i][j] = s.nextInt();
			}
		}
		System.out.println("Display array : ");
		for(int i=0;i<=2;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}

		
	}
}